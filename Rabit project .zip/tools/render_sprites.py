"""
Render Avatar Rabbit sprite frames from a Mixamo-rigged GLB.
Run:  blender -b -P render_sprites.py -- bunny.glb out_dir
Poses are built with world-axis rotations, so they do not depend on the
rig's local bone axes.
"""
import bpy, sys, os, math, re, traceback
from mathutils import Matrix, Vector

SIZE = 256

def main():
    argv = sys.argv[sys.argv.index("--") + 1:]
    glb, out = argv[0], argv[1]
    os.makedirs(out, exist_ok=True)

    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=glb)

    arm = next(o for o in bpy.data.objects if o.type == 'ARMATURE')
    meshes = [o for o in bpy.data.objects if o.type == 'MESH']
    scene = bpy.context.scene

    # ---- character size / framing -------------------------------------------------
    pts = [m.matrix_world @ Vector(c) for m in meshes for c in m.bound_box]
    xs = [p.x for p in pts]; ys = [p.y for p in pts]; zs = [p.z for p in pts]
    zmin, zmax = min(zs), max(zs)
    H = zmax - zmin
    cx = (min(xs) + max(xs)) / 2
    cy = (min(ys) + max(ys)) / 2
    print("character height", H, "center", cx, cy)

    # ---- bones --------------------------------------------------------------------
    def canon(n):
        return re.sub(r'^mixamorig[:_]?', '', n)
    PB = {canon(pb.name): pb for pb in arm.pose.bones}
    M3 = arm.matrix_world.to_3x3().inverted()
    warned = set()
    X, Y, Z = (1, 0, 0), (0, 1, 0), (0, 0, 1)

    def update():
        bpy.context.view_layer.update()

    def reset():
        for pb in arm.pose.bones:
            pb.rotation_mode = 'QUATERNION'
            pb.location = (0, 0, 0)
            pb.rotation_quaternion = (1, 0, 0, 0)
            pb.scale = (1, 1, 1)
        update()

    def get(name):
        pb = PB.get(name)
        if pb is None and name not in warned:
            warned.add(name)
            print("WARNING: bone not found:", name)
        return pb

    def rot(name, axis, deg):
        """Rotate a bone about a WORLD axis through its head (call parents first)."""
        pb = get(name)
        if pb is None:
            return
        ax = (M3 @ Vector(axis)).normalized()
        head = pb.matrix.translation.copy()
        R = Matrix.Translation(head) @ Matrix.Rotation(math.radians(deg), 4, ax) @ Matrix.Translation(-head)
        pb.matrix = R @ pb.matrix
        update()

    def move(name, vec):
        pb = get(name)
        if pb is None:
            return
        pb.matrix = Matrix.Translation(M3 @ Vector(vec)) @ pb.matrix
        update()

    reset()
    SIGN = {}
    for side in ('Left', 'Right'):
        wx = (arm.matrix_world @ PB[side + 'Arm'].matrix.translation).x
        SIGN[side] = 1 if wx > 0 else -1
    print("arm signs", SIGN)

    def relax():
        reset()
        for side in ('Left', 'Right'):
            rot(side + 'Arm', Y, 62 * SIGN[side])   # arms down from T-pose

    # ---- motions (t goes 0..1) ----------------------------------------------------
    def walk(t):
        ph = 2 * math.pi * t
        move('Hips', (0, 0, H * 0.018 * abs(math.sin(ph))))
        rot('Spine', X, 6)
        for side, off in (('Left', 0.0), ('Right', math.pi)):
            a = 28 * math.sin(ph + off)                 # + = leg back
            k = 38 * max(0.0, -math.cos(ph + off))      # knee bends while leg swings forward
            rot(side + 'UpLeg', X, a)
            rot(side + 'Leg', X, k)
            rot(side + 'Foot', X, -(a + k) * 0.6)
            rot(side + 'Arm', X, -16 * math.sin(ph + off))
        rot('Head', X, -6)

    def idle(t):
        ph = 2 * math.pi * t
        move('Hips', (0, 0, H * 0.006 * math.sin(ph)))
        rot('Spine', X, 1.2 * math.sin(ph))
        rot('Head', Z, 14 * math.sin(ph))               # slowly looks around
        rot('Head', Y, 4 * math.sin(ph + 1.2))

    def wave(t):
        ph = 2 * math.pi * t
        side = 'Left' if SIGN['Left'] > 0 else 'Right'  # the arm that shows on the right of the image
        move('Hips', (0, 0, H * 0.005 * abs(math.sin(ph))))
        rot(side + 'Arm', Y, -(62 + 75))
        rot(side + 'ForeArm', Y, 25 * math.sin(2 * ph))
        rot('Head', Y, 6)

    def stretch(t):
        amt = math.sin(math.pi * t)
        for side in ('Left', 'Right'):
            rot(side + 'Arm', Y, -(62 + 85) * SIGN[side] * amt)
        rot('Spine', X, -10 * amt)
        rot('Head', X, -14 * amt)
        move('Hips', (0, 0, H * 0.012 * amt))

    def nap(t):
        ph = 2 * math.pi * t
        b = math.sin(ph)
        move('Hips', (0, 0, H * 0.004 * b))
        rot('Spine', X, 16 + 1.5 * b)
        rot('Head', X, 24)
        rot('Head', Y, 14)
        rot('Head', Z, 4)

    # name: (frames, camera view, function, closed_loop)
    ANIMS = {
        'walk':    (8, 'side',  walk,    True),
        'idle':    (8, 'front', idle,    True),
        'wave':    (8, 'front', wave,    True),
        'stretch': (10, 'front', stretch, False),
        'nap':     (6, 'front', nap,     True),
    }

    # ---- scene: camera, light, render settings -------------------------------------
    cam_data = bpy.data.cameras.new('cam')
    cam_data.type = 'ORTHO'
    cam_data.ortho_scale = H * 1.35
    D = H * 3
    cam_data.clip_end = D * 4
    cam = bpy.data.objects.new('cam', cam_data)
    scene.collection.objects.link(cam)
    scene.camera = cam
    zc = zmin + H * 0.58
    VIEWS = {   # the rabbit faces -Y after glTF import
        'side':  ((cx + D, cy, zc), (math.radians(90), 0, math.radians(90))),
        'front': ((cx, cy - D, zc), (math.radians(90), 0, 0)),
    }

    sun_data = bpy.data.lights.new('sun', 'SUN')
    sun_data.energy = 2.5
    sun = bpy.data.objects.new('sun', sun_data)
    sun.rotation_euler = (math.radians(50), 0, math.radians(15))
    scene.collection.objects.link(sun)

    world = bpy.data.worlds.new('w')
    world.use_nodes = True
    bg = world.node_tree.nodes['Background']
    bg.inputs[0].default_value = (1, 1, 1, 1)
    bg.inputs[1].default_value = 0.9
    scene.world = world

    scene.render.engine = 'CYCLES'
    scene.cycles.device = 'CPU'
    scene.cycles.samples = 32
    try:
        scene.cycles.use_denoising = True
    except Exception:
        pass
    try:
        scene.view_settings.view_transform = 'Standard'
    except Exception:
        pass
    scene.render.resolution_x = SIZE
    scene.render.resolution_y = SIZE
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = True
    scene.render.image_settings.file_format = 'PNG'
    scene.render.image_settings.color_mode = 'RGBA'

    # ---- render --------------------------------------------------------------------
    for name, (n, view, fn, closed) in ANIMS.items():
        loc, rot_e = VIEWS[view]
        cam.location = loc
        cam.rotation_euler = rot_e
        for i in range(n):
            t = i / n if closed else i / (n - 1)
            relax()
            fn(t)
            update()
            scene.render.filepath = os.path.join(out, "%s_%02d.png" % (name, i))
            bpy.ops.render.render(write_still=True)
            print("rendered", name, i)

try:
    main()
except Exception:
    traceback.print_exc()
    sys.exit(1)
