package com.avatarrabbit

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.random.Random

/**
 * Draws the rabbit in a small overlay window and moves that window around.
 * Battery rules: no camera, no sensors, no wake locks, low frame rates,
 * and the animation loop is fully stopped while the screen is off.
 */
class OverlayService : Service() {

    private sealed class Step {
        class Move(val x: Float, val y: Float) : Step()
        class Do(val anim: String, val ms: Long) : Step()
        class Fall(val y: Float) : Step()
    }

    private lateinit var wm: WindowManager
    private lateinit var view: RabbitView
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var sprites: Sprites
    private var viewAdded = false

    private val handler = Handler(Looper.getMainLooper())
    private val rnd = Random(System.nanoTime())
    private val queue = ArrayDeque<Step>()
    private var current: Step? = null
    private var until = 0L
    private var lastTick = 0L
    private var frame = 0
    private var anim = "idle"

    private var x = 0f
    private var y = 0f
    private var faceLeft = true // sprites are rendered facing left
    private var density = 1f
    private var sizePx = 0
    private var screenW = 0
    private var screenH = 0
    private var floorY = 0f
    private var paused = false
    private var dragging = false

    private val tick = object : Runnable {
        override fun run() {
            if (paused) return
            val delay = step()
            handler.postDelayed(this, delay)
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    paused = true
                    handler.removeCallbacks(tick)
                }
                Intent.ACTION_SCREEN_ON -> {
                    val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                    if (!km.isKeyguardLocked) resume()
                }
                Intent.ACTION_USER_PRESENT -> resume()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        density = resources.displayMetrics.density
        sizePx = (96 * density).toInt()
        sprites = Sprites(this)
        measureScreen()

        view = RabbitView(this)
        lp = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        x = (screenW - sizePx) / 2f
        y = floorY
        lp.x = x.toInt()
        lp.y = y.toInt()
        view.setOnTouchListener(touchListener())
        wm.addView(view, lp)
        viewAdded = true

        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        })

        queue.add(Step.Do("wave", 3000)) // hello!
        handler.post(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        if (viewAdded) try { wm.removeView(view) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun resume() {
        if (!paused) return
        paused = false
        lastTick = 0L
        queue.clear()
        current = null
        queue.add(Step.Do("wave", 3000)) // greeting when you wake the phone
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun measureScreen() {
        val m = wm.currentWindowMetrics
        screenW = m.bounds.width()
        screenH = m.bounds.height()
        val nav = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars()).bottom
        floorY = screenH - nav - sizePx * 0.93f
    }

    // ---- behaviour ----------------------------------------------------------------

    private fun planNext() {
        measureScreen()
        val maxX = (screenW - sizePx).toFloat()
        when (rnd.nextInt(100)) {
            in 0..34 -> {
                queue.add(Step.Move(rnd.nextFloat() * maxX, floorY))
                if (rnd.nextBoolean()) queue.add(Step.Do("idle", rnd.nextLong(2000, 6000)))
            }
            in 35..54 -> queue.add(Step.Do("idle", rnd.nextLong(3000, 8000)))
            in 55..69 -> queue.add(Step.Do("nap", rnd.nextLong(15000, 45000)))
            in 70..79 -> queue.add(Step.Do("stretch", 3500))
            in 80..84 -> queue.add(Step.Do("wave", 3000))
            else -> planPeek(maxX)
        }
    }

    /** Walk to a screen edge, climb up it, peek over the edge for a while, climb back down. */
    private fun planPeek(maxX: Float) {
        val left = rnd.nextBoolean()
        val inX = if (left) 0f else maxX
        val outX = if (left) -sizePx * 0.5f else screenW - sizePx * 0.5f
        val py = screenH * (0.30f + 0.40f * rnd.nextFloat())
        queue.add(Step.Move(inX, floorY))
        queue.add(Step.Move(inX, py))
        queue.add(Step.Move(outX, py))
        queue.add(Step.Do("idle", rnd.nextLong(8000, 20000)))
        if (rnd.nextBoolean()) queue.add(Step.Do("wave", 2500))
        queue.add(Step.Move(inX, py))
        queue.add(Step.Move(inX, floorY))
    }

    /** One animation tick. Returns the delay in ms until the next tick. */
    private fun step(): Long {
        val now = SystemClock.uptimeMillis()
        val dt = if (lastTick == 0L) 0f else (now - lastTick).coerceAtMost(250L) / 1000f
        lastTick = now

        if (dragging) {
            anim = "wave"
        } else {
            if (current == null) {
                val s = queue.removeFirstOrNull() ?: run { planNext(); queue.removeFirstOrNull() }
                current = s
                frame = 0
                when (s) {
                    is Step.Do -> { anim = s.anim; until = now + s.ms }
                    is Step.Move -> anim = "walk"
                    is Step.Fall -> anim = "wave"
                    null -> {}
                }
            }
            when (val s = current) {
                is Step.Do -> if (now >= until) current = null
                is Step.Move -> {
                    val len = 55f * density * dt
                    val dx = s.x - x
                    val dy = s.y - y
                    val d = hypot(dx, dy)
                    if (d <= max(len, 1f)) {
                        x = s.x; y = s.y; current = null
                    } else {
                        x += dx / d * len
                        y += dy / d * len
                        if (abs(dx) > 1f) faceLeft = dx < 0
                    }
                }
                is Step.Fall -> {
                    y += 900f * density * dt
                    if (y >= s.y) { y = s.y; current = null }
                }
                null -> {}
            }
        }

        val frames = sprites.frames(anim)
        if (frames.isNotEmpty()) {
            frame = (frame + 1) % frames.size
            view.bitmap = frames[frame]
        }
        view.flipX = !faceLeft
        view.zzz = if (anim == "nap") frame % 3 + 1 else 0
        lp.x = x.toInt()
        lp.y = y.toInt()
        try { wm.updateViewLayout(view, lp) } catch (_: Exception) {}
        view.invalidate()
        return 1000L / (Sprites.FPS[anim] ?: 6)
    }

    private fun touchListener() = object : View.OnTouchListener {
        var downX = 0f; var downY = 0f
        var startX = 0f; var startY = 0f
        var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = x; startY = y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && hypot(dx, dy) > 12 * density) {
                        moved = true
                        dragging = true
                        queue.clear()
                        current = null
                    }
                    if (moved) { x = startX + dx; y = startY + dy }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    queue.clear()
                    current = null
                    if (moved) {
                        dragging = false
                        x = x.coerceIn(0f, (screenW - sizePx).toFloat())
                        queue.add(Step.Fall(floorY))
                        queue.add(Step.Do("idle", 1500))
                    } else {
                        queue.add(Step.Do("wave", 2500)) // tap = say hi
                    }
                }
            }
            return true
        }
    }

    // ---- notification -------------------------------------------------------------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Rabbit", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Avatar Rabbit is out playing")
            .setContentText("Tap Stop to send the rabbit home")
            .setSmallIcon(android.R.drawable.star_on)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
                ).build()
            )
            .build()
        startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    companion object {
        const val ACTION_STOP = "com.avatarrabbit.STOP"
        private const val CHANNEL = "rabbit"
        private const val NOTIF_ID = 1
    }
}
