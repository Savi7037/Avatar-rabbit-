package com.avatarrabbit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

class RabbitView(context: Context) : View(context) {
    var bitmap: Bitmap? = null
    var flipX = false
    var zzz = 0 // 0 = none, 1..3 = number of floating "z"

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val zPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C8CE0")
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val dst = RectF()

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        canvas.save()
        if (flipX) canvas.scale(-1f, 1f, w / 2f, h / 2f)
        dst.set(0f, 0f, w, h)
        canvas.drawBitmap(b, null, dst, paint)
        canvas.restore()
        for (i in 0 until zzz) {
            zPaint.textSize = w * (0.10f + 0.04f * i)
            canvas.drawText("z", w * (0.62f + 0.10f * i), h * (0.28f - 0.07f * i), zPaint)
        }
    }
}
