package com.avatarrabbit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory

/** Loads pre-rendered frames: assets/sprites/<anim>_<NN>.png */
class Sprites(context: Context) {
    private val anims = LinkedHashMap<String, MutableList<Bitmap>>()

    init {
        val am = context.assets
        val files = (am.list("sprites") ?: emptyArray()).filter { it.endsWith(".png") }.sorted()
        for (f in files) {
            val name = f.substringBeforeLast("_")
            am.open("sprites/$f").use { stream ->
                BitmapFactory.decodeStream(stream)?.let { anims.getOrPut(name) { mutableListOf() }.add(it) }
            }
        }
    }

    fun frames(name: String): List<Bitmap> =
        anims[name] ?: anims["idle"] ?: anims.values.firstOrNull() ?: emptyList()

    companion object {
        /** Frames per second for each animation. Lazy animations run slowly to save battery. */
        val FPS = mapOf("walk" to 10, "idle" to 4, "wave" to 8, "stretch" to 6, "nap" to 2)
    }
}
